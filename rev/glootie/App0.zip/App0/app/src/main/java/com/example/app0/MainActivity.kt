package com.example.app0

import android.content.res.AssetManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Example of a call to a native method
//        findViewById<TextView>(R.id.sample_text).text = stringFromJNI(this.assets)

    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
//    external fun stringFromJNI(mgr : AssetManager): String
    external fun checkPasswd(pass : String, mgr : AssetManager): String
    fun checkpass(view: View) {
        // Do something in response to button click
        var pass : String = findViewById<EditText>(R.id.textPassword).text.toString()
        var mism : String = checkPasswd(pass,this.assets)
        findViewById<TextView>(R.id.sample_text).text = mism
    }
    companion object {
        // Used to load the 'native-lib' library on application startup.
        init {
            System.loadLibrary("native-lib")
        }
    }
}