
# Reverse NotWannaSigh

from pwn import *
from time import sleep

#p = gdb.debug('/home/ctf/Documents/WPICTF2020/RE/WannaSigh/test/NotWannasigh',
#	'''
#	break main
#	continue
#	''')

p = process('/home/ctf/Documents/WPICTF2020/RE/WannaSigh/test/NotWannasigh')
p.interactive()

